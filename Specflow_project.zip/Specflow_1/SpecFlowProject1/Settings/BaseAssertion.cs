﻿using NUnit.Framework;

namespace SpecFlowProject1.Settings
{
    class BaseAssertion
    {
        public BaseAssertion()
        { }

        public void AssertEqualityForStrings(string expected, string actual)
        {
            Assert.AreEqual(expected, actual);
        }
    }
}
