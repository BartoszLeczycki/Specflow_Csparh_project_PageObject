﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace SpecFlowProject1.Settings
{
    class CommonMethods
    {
        protected IWebDriver driver;
        protected WebDriverWait Wait;
        protected readonly int timeout = 60;

        public CommonMethods(IWebDriver driver)
        {
            this.driver = driver;
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
            PageFactory.InitElements(driver, this);
        }

        public void WaitForElement(IWebElement element)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
        }

        public void WaitUntilTextIsVisable(By by, string text)
        {
            Wait.Until(d => d.FindElement(by).Text.Contains(text));
        }

    }
}
