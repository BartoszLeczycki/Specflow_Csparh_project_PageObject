﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using TechTalk.SpecFlow;

namespace SpecFlowProject1.Hooks
{
    public class TestSettings
    {
        public IWebDriver Driver;
        protected readonly string chromedriver_path = ConfigurationManager.AppSettings["ChromeDriverPath"];
        protected readonly string url = ConfigurationManager.AppSettings["UrlPath"];
        //protected readonly string url = @"https://www.google.com/"
        //protected readonly string chromedriver_path = "C:/Automation/ChromeDriver";

        [BeforeScenario(Order = 0)]
        //[BeforeFeature]
        public void FirstBeforeScenario()
        {
            Driver = new ChromeDriver(chromedriver_path);
            Driver.Manage().Window.Maximize();
        }

        [AfterScenario(Order = 99)]
        //[AfterFeature]
        public void LastAfterScenarioRun()
        {
            Driver.Quit();
        }

    }
}
