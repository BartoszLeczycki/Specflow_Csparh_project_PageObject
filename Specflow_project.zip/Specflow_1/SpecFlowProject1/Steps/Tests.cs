﻿using NUnit.Framework;
using OpenQA.Selenium;
using SpecFlowProject1.Hooks;
using SpecFlowProject1.PageObejct;
using SpecFlowProject1.Settings;
using TechTalk.SpecFlow;

namespace SpecFlowProject1.Steps
{
    [Binding]
    public sealed class Tests : TestSettings
    {
        HomePage homepage;
        ResultPage resultpage;
        CommonMethods commonmethods;


        [BeforeScenario(Order = 1)]
        public void BeforeScenario()
        {
            homepage = new HomePage(Driver);
            resultpage = new ResultPage(Driver);
            commonmethods = new CommonMethods(Driver);
        }

        [AfterScenario(Order = 98)]
        public void AfterScenario()
        {
            Driver.Close();
        }

        [Given("Accept google conditions")]
        public void AcceptGooogleConditions()
        {
            homepage.goToMainPage()
                .AcceptConditions();
        }

        [Given("Enter (.*) in the browser")]
        public void EnterValueInTheBrowser(string name)
        {
            homepage.EnterText(name);
        }

        [Given("Click in the search button")]
        public void ClickInTheSearchButton()
        {
            homepage.ClickInSearchButton();
        }

        [When("Searching process is finished for (.*)")]
        public void SearchingProcessIsDinished(string name)
        {
            commonmethods.WaitUntilTextIsVisable(By.XPath("//div[@id='wp-tabs-container']//h2"), name);
        }

        [Then("The (.*) should be visible on the UI")]
        public void ValueShouldBeVisibleOnUI(string name)
        {
            string text = resultpage.SearchNameText;
            Assert.AreEqual(name.ToLower(), text.ToLower());

            string numberofresult = resultpage.GetNumberOfResults();
            Assert.IsTrue(!string.IsNullOrEmpty(numberofresult));

            string[] resultheaders = resultpage.GetResutsHeaders();

            for (int i = 0; i < resultheaders.Length; i++)
            {
                Assert.IsTrue(!string.IsNullOrEmpty(resultheaders[i]));
            }
        }
    }
}
