﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace SpecFlowProject1
{
    class PageObjectSettings
    {
        protected IWebDriver Driver;
        protected WebDriverWait Wait;

        public PageObjectSettings(IWebDriver driver)
        {
            this.Driver = driver;
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            PageFactory.InitElements(driver, this);
        }
    }
}
