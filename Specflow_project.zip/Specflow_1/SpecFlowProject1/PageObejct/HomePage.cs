﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using SpecFlowProject1.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowProject1.PageObejct
{
    class HomePage : PageObjectSettings
    {
        CommonMethods commonmethods;

        public HomePage(IWebDriver driver) : base(driver)
        {
            commonmethods = new CommonMethods(driver);
        }

        protected readonly string url = @"https://www.google.com/";

        [FindsBy(How = How.XPath, Using = ("//input[@class='gLFyf gsfi']"))]
        protected IWebElement InputTextField { get; set; }
        [FindsBy(How = How.XPath, Using = ("//input[@class='gNO89b']"))]
        protected IList<IWebElement> SearchButtons { get; set; }
        [FindsBy(How = How.XPath, Using = ("//span[@class='RveJvd snByac'][contains(text(),'Zgadzam się')]"))]
        protected IWebElement AcceptTermsButton { get; set; }
        [FindsBy(How = How.XPath, Using = ("//iframe"))]
        protected IWebElement IFrameElement { get; set; }

        public HomePage goToMainPage()
        {
            Driver.Navigate().GoToUrl(url);
            return this;
        }

        public HomePage EnterText(string text)
        {
            commonmethods.WaitForElement(InputTextField);
            InputTextField.SendKeys(text);
            return this;
        }

        public HomePage ClickInSearchButton()
        {
            commonmethods.WaitForElement(SearchButtons[0]);
            SearchButtons[0].Click();
            return this;
        }

        public HomePage AcceptConditions()
        {
            Driver.SwitchTo().Frame(IFrameElement);
            commonmethods.WaitForElement(AcceptTermsButton);
            AcceptTermsButton.Click();
            return this;
        }

        //public void WaitForElement(IWebElement element)
        //{ Wait.Until(ExpectedConditions.ElementToBeClickable(element)); }
    }
}
