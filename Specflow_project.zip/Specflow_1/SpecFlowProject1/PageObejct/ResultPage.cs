﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowProject1.PageObejct
{
    class ResultPage : PageObjectSettings
    {
        public ResultPage(IWebDriver driver) : base(driver) { }

        [FindsBy(How = How.XPath, Using = ("//div[@id='wp-tabs-container']//h2"))]
        protected IWebElement SearchName { get; set; }
        [FindsBy(How = How.XPath, Using = ("//input[@class='gNO89b']"))]
        protected IList<IWebElement> SearchButtons { get; set; }


        //public void WaitUntilTextIsVisable(By by, string text)
        //{
        //    Wait.Until(d => d.FindElement(by).Text.Contains(text));
        //}

        public string SearchNameText => SearchName.Text;

        public string GetNumberOfResults()
        {
            return Driver.FindElement(By.XPath("//div[@id='result-stats']")).Text;
        }

        public string[] GetResutsHeaders()
        {
            return Driver.FindElements(By.XPath("//a//h3")).Select(x => x.Text.Trim()).ToArray();
        }

    }
}
